package com.ojas.java8;

public class LengthExp {

	public static void main(String[] args) {

		method(s -> s.length());

	}

	public static void method(FindLenght fl) {
		System.out.println(fl.stringlength("this is lamda expression"));
	}

	interface FindLenght {
		int stringlength(String s);
	}

}
