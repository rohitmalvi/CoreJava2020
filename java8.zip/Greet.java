package com.ojas.java8;

public interface Greet {
	public  void perform();

}
