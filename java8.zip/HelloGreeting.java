package com.ojas.java8;

public class HelloGreeting implements Greet{

	@Override
	public void perform() {
		System.out.println("hello World good morning");
		
	}
	

}
