package com.ojas.java8;

public class LamdaExp {

	public void show(Greet msg) {
		msg.perform();
	}

	public static void main(String[] args) {

		LamdaExp exp = new LamdaExp();

		Greet lamda = () -> System.out.println("This is lamda Exp");

		Greet innerGreet = new Greet() {
			public void perform() {
				System.out.println("This is inner calss");
			}
		};

		exp.show(() -> System.out.println("This is lamda Exp"));
		exp.show(innerGreet);

	}

}
