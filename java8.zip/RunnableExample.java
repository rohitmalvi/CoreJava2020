package com.ojas.java8;

public class RunnableExample {
	public static void main(String[] args) {
		Thread tt = new Thread() {
			@Override
			public void run() {
				System.out.println("this is run method");
			}

		};
		tt.run();
		Thread th = new Thread(() -> System.out.println("This is new thread"));
		th.run();
	}
}